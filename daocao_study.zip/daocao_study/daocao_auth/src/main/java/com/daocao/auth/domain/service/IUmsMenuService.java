package com.daocao.auth.domain.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.daocao.auth.domain.entity.UmsMenu;

public interface IUmsMenuService extends IService<UmsMenu> {
}
