package com.daocao.auth.domain.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.daocao.auth.domain.entity.UmsRole;

public interface IUmsRoleService extends IService<UmsRole> {
}
