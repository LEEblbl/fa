package com.daocao.auth.domain.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.daocao.auth.domain.entity.UmsRole;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UmsRoleMapper extends BaseMapper<UmsRole> {
}
