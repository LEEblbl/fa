package com.daocao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaoCaoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DaoCaoApplication.class, args);
    }
}
